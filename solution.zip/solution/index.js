// Please don't change the pre-written code
// Import the necessary modules here

// Write your code here
//create a node-js server

//import http libraby or module
const http = require('http') ;

//create the server
const server = http.createServer((req , res)=>{
    //Here it is the request
    res.end("Welcome to the Ninja Server")
});

// Specift a port to listen to client's request
server.listen(8080 , ()=>{
    console.log('Sever is listening on port 8080');
});



module.exports = server;
